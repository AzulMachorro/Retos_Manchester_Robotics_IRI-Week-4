import cv2
import numpy as np
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32
import rclpy
from rclpy.node import Node

class TrafficLightDetector(Node):

    def __init__(self):
        super().__init__('traffic_light_detector')

        # Variables para la camara
        self.valid_img = False
        self.bridge = CvBridge()

        # Suscriptor a la camara del robot
        self.sub = self.create_subscription(Image, '/video_source/raw', self.camera_callback, rclpy.qos.qos_profile_sensor_data)
        
        # Publicador del color de semaforo detectado
        self.pubv = self.create_publisher(Float32, '/color', 10)

        # Timer period
        timer_period = 0.05
        self.timer = self.create_timer(timer_period, self.timer_callback)

        # Radio del kernel circular en centimetros
        self.radius_cm = 5  

        # Variable que guarda el ultimo color detectado para mantener la velocidad sin cambios
        self.last_color = None 

        # Tipo de dato a publicar en topico /color
        self.color = Float32()

        # Impresion en terminal que indica que el nodo ha sido inicializado correctamente
        self.get_logger().info('Traffic light detector node successfully initialized!!!')

    # Funcion callback para ejecucion de la vision por computadora
    def timer_callback(self):
        # Primero se comprueba que haya alguna imagen leida
        try:
            if self.valid_img:
                hsv = cv2.cvtColor(self.img, cv2.COLOR_BGR2HSV)
                
                # Limites de los colores en HSV
                lower_red1 = (0, 100, 100)
                upper_red1 = (10, 255, 255)
                lower_red2 = (170, 100, 100)
                upper_red2 = (180, 255, 255)

                lower_green = (40, 50, 50)
                upper_green = (80, 255, 255)

                lower_yellow = (20, 100, 100)
                upper_yellow = (35, 255, 255)
                
                # Umbrales para la deteccion de colores 
                mask_red1 = cv2.inRange(hsv, lower_red1, upper_red1)
                mask_red2 = cv2.inRange(hsv, lower_red2, upper_red2)
                mask_green = cv2.inRange(hsv, lower_green, upper_green)
                mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
                
                # Mascaras para la deteccion de colores
                mask_combined = cv2.bitwise_or(mask_red1, mask_red2)
                mask_combined = cv2.bitwise_or(mask_combined, mask_green)
                mask_combined = cv2.bitwise_or(mask_combined, mask_yellow)
                
                # Operacion morfologica para reducir ruido de la imagen recibida
                kernel = np.ones((5, 5), np.uint8)
                mask_combined = cv2.morphologyEx(mask_combined, cv2.MORPH_OPEN, kernel)
                
                # Deteccion de objetos circulares con la forma del kernel
                circle_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2*self.radius_cm, 2*self.radius_cm))
                mask_combined = cv2.dilate(mask_combined, circle_kernel)
                
                # Deteccion de bordes de los objetos en la imagen
                contours, _ = cv2.findContours(mask_combined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                
                # Deteccion del objeto mas grande en la imagen
                max_area_red = 0
                max_contour_red = None
                max_area_green = 0
                max_contour_green = None
                max_area_yellow = 0
                max_contour_yellow = None
                
                for contour in contours:
                    area = cv2.contourArea(contour)
                    
                    if area > max_area_red and self.is_color_contour(hsv, contour, lower_red1, upper_red1, lower_red2, upper_red2):
                        max_area_red = area
                        max_contour_red = contour
                    
                    if area > max_area_green and self.is_color_contour(hsv, contour, lower_green, upper_green):
                        max_area_green = area
                        max_contour_green = contour
                    
                    if area > max_area_yellow and self.is_color_contour(hsv, contour, lower_yellow, upper_yellow):
                        max_area_yellow = area
                        max_contour_yellow = contour
                
                # Impresion del color del objeto detectado y publicacion al topico
                if max_area_red > max_area_green and max_area_red > max_area_yellow:
                    self.get_logger().info("Color detected: Red")
                    self.color = 0.0
                elif max_area_green > max_area_red and max_area_green > max_area_yellow:
                    self.get_logger().info("Color detected: Green")
                    self.color = 1.0
                elif max_area_yellow > max_area_red and max_area_yellow > max_area_green:
                    self.get_logger().info("Color detected: Yellow")
                    self.color = 0.5
                else:
                    self.get_logger().info("No color detected")
                    # Si se detecta el color rojo mantener al robot detenido hasta hallar luz verde
                    if self.last_color == "Red":
                        self.color = 0.0

                # Publicar la proporcion de velocidad acorde al color
                color_msg = Float32()
                color_msg.data = self.color
                self.pubv.publish(color_msg)

                # Actualizar ultimo color detectado 
                if max_area_red > max_area_green and max_area_red > max_area_yellow:
                    self.last_color = "Red"
                elif max_area_green > max_area_red and max_area_green > max_area_yellow:
                    self.last_color = "Green"
                elif max_area_yellow > max_area_red and max_area_yellow > max_area_green:
                    self.last_color = "Yellow"

        # Si no hay imagen mandar mensaje de error para no matar al nodo y esperar alguna imagen 
        except Exception as e:
            self.get_logger().info(f'Failed to process image: {str(e)}')


    # Callback para leer la imagen del topico publicador de la camara del robot
    def camera_callback(self, msg):
        try:
            self.img = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            self.valid_img = True
        except Exception as e:
            self.get_logger().info(f'Failed to get an image: {str(e)}')

    # Funcion para determinar el color del objeto detectado y su contorno 
    def is_color_contour(self, hsv, contour, lower, upper, lower2=None, upper2=None):
        mask = cv2.inRange(hsv, lower, upper)
        
        if lower2 is not None and upper2 is not None:
            mask2 = cv2.inRange(hsv, lower2, upper2)
            mask = cv2.bitwise_or(mask, mask2)
        
        x, y, w, h = cv2.boundingRect(contour)
        mask_roi = mask[y:y+h, x:x+w]
        return cv2.countNonZero(mask_roi) > 0

def main(args=None):
    rclpy.init(args=args)
    traffic_light_detector = TrafficLightDetector()
    rclpy.spin(traffic_light_detector)
    traffic_light_detector.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
