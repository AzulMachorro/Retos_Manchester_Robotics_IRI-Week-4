import cv2
import numpy as np
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32
import rclpy
from rclpy.node import Node

class TrafficLightDetector(Node):

    def __init__(self):
        super().__init__('traffic_light_detector')

        # Variables for camera
        #self.img = np.ndarray((480, 640, 3))  # Set image resolution to 480p
        self.valid_img = False
        self.bridge = CvBridge()
        self.sub = self.create_subscription(Image, '/video_source/raw', self.camera_callback, rclpy.qos.qos_profile_sensor_data)
        #self.pub = self.create_publisher(Image, '/img_processing/color', 10)
        self.pubv = self.create_publisher(Float32, '/color', 10)

        # Timer period
        timer_period = 0.05
        self.timer = self.create_timer(timer_period, self.timer_callback)

        # Subscriber for velocity
        #self.subscriber = self.create_subscription(Twist, '/prueba_vel', self.vel_callback, 10)

        # Radius of the circular kernel in centimeters (adjust as needed)
        self.radius_cm = 5  # Example radius of 5 cm

        self.last_color = None  # Initialize last detected color
        #self.last_linear_x = 0.0  # Initialize last linear x velocity
        #self.last_angular_z = 0.0  # Initialize last angular z velocity

        #self.cmd_vel = Twist()  # Initialize cmd_vel here
        #self.linear_x = 0.0  # Initialize linear x velocity
        #self.angular_z = 0.0  # Initialize angular z velocity

        self.color = Float32()

        self.get_logger().info('Traffic light detector node successfully initialized!!!')

    #def vel_callback(self, msg):
    #    self.linear_x = msg.linear.x
    #    self.angular_z = msg.angular.z

    def timer_callback(self):
        try:
            if self.valid_img:
                hsv = cv2.cvtColor(self.img, cv2.COLOR_BGR2HSV)
                
                # Define color ranges
                lower_red1 = (0, 100, 100)
                upper_red1 = (10, 255, 255)
                lower_red2 = (170, 100, 100)
                upper_red2 = (180, 255, 255)

                lower_green = (40, 50, 50)
                upper_green = (80, 255, 255)

                lower_yellow = (20, 100, 100)
                upper_yellow = (35, 255, 255)
                
                # Threshold the HSV image to get only specific colors
                mask_red1 = cv2.inRange(hsv, lower_red1, upper_red1)
                mask_red2 = cv2.inRange(hsv, lower_red2, upper_red2)
                mask_green = cv2.inRange(hsv, lower_green, upper_green)
                mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
                
                # Combine masks for all colors
                mask_combined = cv2.bitwise_or(mask_red1, mask_red2)
                mask_combined = cv2.bitwise_or(mask_combined, mask_green)
                mask_combined = cv2.bitwise_or(mask_combined, mask_yellow)
                
                # Apply morphological opening to reduce noise
                kernel = np.ones((5, 5), np.uint8)
                mask_combined = cv2.morphologyEx(mask_combined, cv2.MORPH_OPEN, kernel)
                
                # Apply dilation with circular kernel to emphasize circular shapes
                circle_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2*self.radius_cm, 2*self.radius_cm))
                mask_combined = cv2.dilate(mask_combined, circle_kernel)
                
                # Find contours in the combined mask
                contours, _ = cv2.findContours(mask_combined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                
                # Find the largest contour area for each color
                max_area_red = 0
                max_contour_red = None
                max_area_green = 0
                max_contour_green = None
                max_area_yellow = 0
                max_contour_yellow = None
                
                for contour in contours:
                    area = cv2.contourArea(contour)
                    
                    if area > max_area_red and self.is_color_contour(hsv, contour, lower_red1, upper_red1, lower_red2, upper_red2):
                        max_area_red = area
                        max_contour_red = contour
                    
                    if area > max_area_green and self.is_color_contour(hsv, contour, lower_green, upper_green):
                        max_area_green = area
                        max_contour_green = contour
                    
                    if area > max_area_yellow and self.is_color_contour(hsv, contour, lower_yellow, upper_yellow):
                        max_area_yellow = area
                        max_contour_yellow = contour
                
                # Print color detected and adjust velocity accordingly
                if max_area_red > max_area_green and max_area_red > max_area_yellow:
                    self.get_logger().info("Color detected: Red")
                    self.color = 0.0
                elif max_area_green > max_area_red and max_area_green > max_area_yellow:
                    self.get_logger().info("Color detected: Green")
                    self.color = 1.0
                elif max_area_yellow > max_area_red and max_area_yellow > max_area_green:
                    self.get_logger().info("Color detected: Yellow")
                    self.color = 0.5
                else:
                    self.get_logger().info("No color detected")
                    if self.last_color == "Red":
                        # If last detected color was red, keep velocity 0 until green is detected
                        self.color = 0.0

                # Publish the color value
                color_msg = Float32()
                color_msg.data = self.color
                self.pubv.publish(color_msg)

                # Update last detected color
                if max_area_red > max_area_green and max_area_red > max_area_yellow:
                    self.last_color = "Red"
                elif max_area_green > max_area_red and max_area_green > max_area_yellow:
                    self.last_color = "Green"
                elif max_area_yellow > max_area_red and max_area_yellow > max_area_green:
                    self.last_color = "Yellow"

        except Exception as e:
            self.get_logger().info(f'Failed to process image: {str(e)}')



    def camera_callback(self, msg):
        try:
            self.img = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            self.valid_img = True
        except Exception as e:
            self.get_logger().info(f'Failed to get an image: {str(e)}')

    def is_color_contour(self, hsv, contour, lower, upper, lower2=None, upper2=None):
        mask = cv2.inRange(hsv, lower, upper)
        
        if lower2 is not None and upper2 is not None:
            mask2 = cv2.inRange(hsv, lower2, upper2)
            mask = cv2.bitwise_or(mask, mask2)
        
        x, y, w, h = cv2.boundingRect(contour)
        mask_roi = mask[y:y+h, x:x+w]
        return cv2.countNonZero(mask_roi) > 0

    def draw_bounding_box(self, img, contour, color):
        if contour is not None:
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)

def main(args=None):
    rclpy.init(args=args)
    traffic_light_detector = TrafficLightDetector()
    rclpy.spin(traffic_light_detector)
    traffic_light_detector.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
