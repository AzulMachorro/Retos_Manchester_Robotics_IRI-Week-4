import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from geometry_msgs.msg import Pose2D
from geometry_msgs.msg import Twist
import numpy as np


#Definición de la clase 
class Controller(Node):
    #Constructor 
    def __init__(self):
        
        #Definición del tópico
        super().__init__('Azul_Controller_node')
        
        #Variables para lectura de topico /odom
        self.x = 0.0
        self.y = 0.0
        self.w = 0.0

        #Punto objetivo
        self.xp = 0.0
        self.yp = 0.0
        self.wp = 0.0

        #valor que nos regresa camarita dependiendo el color visto
        self.color = 1.0
        
        #Creación del tópico publicador: cmd_vel
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        
        #Creación del tópico subcriptor: odom
        self.subscriber = self.create_subscription(Pose2D, 'odom', self.pose_callback, 10)
        
        #Creación del tópico subcriptor: point
        self.subscriberP = self.create_subscription(Pose2D, 'Point', self.point_callback, 10)
        
        #Creación del tópico subcriptor: color
        self.subscriberC = self.create_subscription(Float32, 'color', self.color_callback, 10)
        
        #Definición del periodo de tiempo
        timer_period = 0.01

        #Timer para operaciones
        self.timer = self.create_timer(timer_period, self.timer_callback)

        #Confirmación de la creación del nodo
        self.get_logger().info('Controller position error node successfully initialized!!!')

        #Tipo de mensaje 
        self.msg = Float32()
        
        #Parametros de los controladores PI
        self.kp_ang = 0.4
        self.ki_ang = 0.0
        self.kp_lin = 0.3
        self.ki_lin = 0.0
        
        #Variables de error integral
        self.error_integral_ang = 0.0
        self.error_integral_lin = 0.0
     
    def pose_callback(self, msg):
        #Datos de pose recibidos
        self.x = msg.x
        self.y = msg.y
        self.w = msg.theta
        #self.get_logger().info(f'Received pose: x={msg.x}, y={msg.y}, theta={msg.theta}')
        
    def point_callback(self, msg):
        #Datos de objetivo recibidos
        self.xp = msg.x
        self.yp = msg.y

    def color_callback(self, msg):
        #Datos de objetivo recibidos
        self.color = msg.data

    #Método del timer
    def timer_callback(self):
        #inicializamos a 0.0 la varibles que no utilizaremos del twist y mandaremos a cmd_vel
        cmd_vel = Twist()
        cmd_vel.linear.y = 0.0
        cmd_vel.linear.x = 0.0
        cmd_vel.linear.z = 0.0
        cmd_vel.angular.x = 0.0
        cmd_vel.angular.y = 0.0

        #inicializamos la variables que almacenaran las velocidades angulares y lineales
        lin_control_output = 0.0
        ang_control_output = 0.0

        #calculamos el angulo del punto en donde nos encontramos y el punto objetivo
        self.wp = np.arctan2((self.yp - self.y),(self.xp - self.x))
        #calculamos el error angular
        error_w = self.wp - self.w

        #calculamos el error lineal oteniendo la distancia entre el punto donde nos encontramos y el punto objetivo
        error_v = np.sqrt(((self.yp - self.y)**2) + ((self.xp - self.x)**2))

        #verificamos que el robot todavia no ha llegado al objetivo
        if error_w >= 0.05 or error_w <= -0.05:
            #verificamos que los valores enten dentro de -pi a pi
            if error_w >= np.pi:
                error_w -= 2*np.pi
            elif error_w <= -np.pi:
                error_w += np.pi
            #Aplicamos la KP_w
            ang_control_output = self.kp_ang * error_w
            #Aplicamos un limite minimo para que no nos de valores con los que el bot no se puede mover 
            if ang_control_output < 0.1 and ang_control_output > 0.0:
                ang_control_output = 0.1
            if ang_control_output > -0.1 and ang_control_output < 0.0:
                ang_control_output = -0.1
            #le mandamos una velocidad lineal de 0.0 hasta que su error angular sea 0.0
            lin_control_output = 0.0
        #si el error_w es 0.0     
        else:
            #verificamos que el robot todavia no ha llegado al objetivo lineal
            if error_v >= 0.05 or error_v <= -0.5:
                #Aplicamos la KP_v
                lin_control_output = self.kp_lin * error_v
                #le mandamos una velocidad angular de 0.0 hasta que su error linear sea 0.0
                ang_control_output = 0.0
            #si el error_v es 0.0
            else:
                #le damos una velocidad linear y angular de 0.0
                lin_control_output = 0.0
                ang_control_output = 0.0

        #le damos limites a las velocidades
        if ang_control_output > 0.25:
            ang_control_output = 0.25

        if ang_control_output < -0.25:
            ang_control_output = -0.25

        if lin_control_output > 0.25:
            lin_control_output = 0.25

        if lin_control_output < -0.25:
            lin_control_output = -0.25

        #multiplicamos por el valor que nos mando la camara dependiendo el color que detecta
        ang_control_output = ang_control_output * self.color
        lin_control_output = lin_control_output * self.color

        #mandamos las velocidades a cmd_vel
        cmd_vel.angular.z = ang_control_output
        cmd_vel.linear.x = lin_control_output
        self.publisher.publish(cmd_vel)

        #mensajes de depuración
        self.get_logger().info(f'V: {lin_control_output}')
        self.get_logger().info(f'W: {ang_control_output}')
        self.get_logger().info(f'error_V: {error_v}')
        self.get_logger().info(f'error_W: {error_w}')

#Main Fnc
def main(args=None):
    #Inicialiation for rclpy 
    rclpy.init(args=args)
    #create node
    m_p = Controller()
    #Spin method for publisher calback
    rclpy.spin(m_p)
    #Destoy node
    m_p.destroy_node()
    #rclpy shutdown
    rclpy.shutdown()

#main call method
if __name__ == '__main__':    
    main()
    
